package practical4;


public class FixedDepositAccount extends SavingAccount{
    double interestRate = 9.12;
    double getInterest(){
        return interestRate;
    }
}
