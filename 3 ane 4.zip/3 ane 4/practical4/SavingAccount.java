package practical4;
public class SavingAccount extends BankAccount{
    double interestRate = 6.75;
    double getInterest(){
        return interestRate;
    }
}
