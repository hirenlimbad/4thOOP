package practical4;
public class Shape{
    double height;
    double width;

    void setData(double height, double width){
        this.height = height;
        this.width = width;
    }

    void display_area(){
        System.out.println("Kya karr raha hain bhai tu?");
    }
}


