package practical4;
public class Rectangle extends Shape{
    public void display_area() {
        double area = height * width;
        System.out.println("Area of Rectangle: " + area);
    }
}
