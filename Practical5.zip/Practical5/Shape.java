
abstract class Shape {
    abstract int area();
}
