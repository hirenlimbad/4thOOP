

interface Exam {
    boolean pass(int mark);
}


interface Classify {

    String division (int average);
    
}