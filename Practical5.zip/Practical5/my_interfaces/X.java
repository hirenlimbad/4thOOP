

public class X implements I3 {
    
}
