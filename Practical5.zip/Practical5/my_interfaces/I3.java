

interface I3 extends I1, I2{
    
}
