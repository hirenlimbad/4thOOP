

public interface I1 {

    
}